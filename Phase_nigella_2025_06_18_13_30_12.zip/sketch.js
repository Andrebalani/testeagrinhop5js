//variáveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 22;
let raio = diametro /2;

//velocidade da bolinha

let velocidadexBolinha = 6;
let velocidadeYBolinha=6;

//variáveis da raquete
let xrect=5;
let yrect=150;
let rectComprimento=10;
let rectAltura= 90

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  mostraBolinha ();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete();
}
  


function mostraBolinha (){
  circle(xBolinha,yBolinha,diametro);
  
}
function movimentaBolinha (){
  xBolinha +=velocidadexBolinha;
  yBolinha +=velocidadeYBolinha;
  
}

function verificaColisaoBorda(){
  if (xBolinha + raio > width || xBolinha - raio<0){
    velocidadexBolinha *=-1;
    
  }
  if (yBolinha + raio > height || yBolinha - raio<0){
    velocidadeYBolinha *=-1;
    
  }
}
function mostraRaquete(){
  rect(xrect, yrect, rectComprimento, rectAltura);
  
}
